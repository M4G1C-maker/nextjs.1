import styles from '../styles/Footer.module.css';
import Image from 'next/image';
import Link from 'next/link';

const Footer = () => {
  return (
    <div className={styles.container}>
      <div className={styles.card}>
        <div className={styles.cardL}>
          <h1 className={styles.title}>Creative.CORP</h1>
          <h1 className={styles.linkTitle}>
            <Link passHref href="/contact">
              <span className={styles.linkText}>Work with us</span>
            </Link>
          </h1>
        </div>
        <div className={styles.cardS}>
          <div className={styles.cardItem}>
            Follow us :
            <div className={styles.social}>
              <Image className={styles.icons} src="/img/facebook-square.svg" alt="50px" width="50px" height="50px" />
              <Image className={styles.icons} src="/img/instagram.svg" alt="50px" width="50px" height="50px" />
              <Image className={styles.icons} src="/img/twitter-square.svg" alt="50px" width="50px" height="50px" />
            </div>
          </div>
        </div>
      </div>
      <div className={styles.copyright}>
        <p>@ 2022 M4G1C Design, All Rights Reserved</p>
      </div>
    </div>
  );
};

export default Footer;
