import styles from '../styles/Contact.module.css';
import Circle from '../components/Circle';

const Contact = () => {
  return (
    <div className={styles.container}>
      <Circle backgroundColor="green" left="-40vh" top="-20vh" />
      <Circle backgroundColor="yellow" right="-30vh" bottom="-60vh" />
      <h1 className={styles.title}>Gei In Touch</h1>
      <form action="" className={styles.form}>
        <input className={styles.inputS} placeholder="Username" />
        <input className={styles.inputS} placeholder="Phone" />
        <input className={styles.inputL} placeholder="Email" />
        <input className={styles.inputL} placeholder="Subject" />
        <textarea placeholder="Message" rows="6" className={styles.textarea} />
        <button className={styles.button}>Submit</button>
      </form>
    </div>
  );
};

export default Contact;
